"""gr.GaussianRender() component."""

from __future__ import annotations

from typing import (Any, Literal)
from gradio.components.base import Component
from gradio.data_classes import FileData
from gradio.events import Events

class gaussian_render(Component):
    """
    Creates an webrtc component link to aliyun-rtc-sdk which can be used to pull or push media stream.
    """

    EVENTS: Events = [
        'start',
    ]

    data_model = FileData

    def __init__(
        self,
        *,
        container: bool = True,
        scale: int | None = None,
        min_width: int = 160,
        interactive: bool | None = None,
        visible: bool = True,
        elem_id: str | None = None,
        elem_classes: list[str] | str | None = None,
        render: bool = True,
        key: int | str | None = None,
        height: int | str | None = None,
        width: int | str | None = None,
        assets: str | None = None,
    ):
        """
        Parameters:
            container: If True, will place the component in a container - providing some extra padding around the border.
            scale: relative size compared to adjacent Components. For example if Components A and B are in a Row, and A has scale=2, and B has scale=1, A will be twice as wide as B. Should be an integer. scale applies in Rows, and to top-level Components in Blocks where fill_height=True.
            min_width: minimum pixel width, will wrap if not sufficient screen space to satisfy this value. If a certain scale value results in this Component being narrower than min_width, the min_width parameter will be respected first.
            interactive: if True, will allow users to upload and edit an image; if False, can only be used to display images. If not provided, this is inferred based on whether the component is used as an input or output.
            visible: If False, component will be hidden.
            elem_id: An optional string that is assigned as the id of this component in the HTML DOM. Can be used for targeting CSS styles.
            elem_classes: An optional list of strings that are assigned as the classes of this component in the HTML DOM. Can be used for targeting CSS styles.
            render: If False, component will not render be rendered in the Blocks context. Should be used if the intention is to assign event listeners now but render the component later.
            key: if assigned, will be used to assume identity across a re-render. Components that have the same key across a re-render will have their value preserved.
            height: the height of the webrtc component
            width: the width of the webrtc component
        """
        self.height = height
        self.width = width
        self.assets = assets
        
        print('gaussian render init')
        
        
        super().__init__(
            container=container,
            scale=scale,
            min_width=min_width,
            interactive=interactive,
            visible=visible,
            elem_id=elem_id,
            elem_classes=elem_classes,
            render=render,
            key=key,

        )
    
    def preprocess(self, payload: str | None) -> str | None:
        """
        Parameters:
            payload: the text entered in the aliyun_webrtc.
        Returns:
            Passes text value as a {str} into the function.
        """
        return None if payload is None else str(payload)

    def postprocess(self, value: Any) -> str:
        """
        Parameters:
            value: Expects a media stream for video play
        Returns:
            VideoData object
        """
        return value
      

    def example_payload(self) -> Any:
        return 'channel 1'

    def example_value(self) -> Any:
        return "https://xxx/xx.mp4"
    